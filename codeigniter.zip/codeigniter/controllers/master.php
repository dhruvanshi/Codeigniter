<?php

class Master extends Controller {

        function Master() {

          	parent::Controller();

		if( function_exists( 'pinba_script_name_set' ) ) {

			pinba_script_name_set('/'.$this->router->fetch_class().'/'.$this->router->fetch_method());

		}

                $this->lang->load('tank_auth');
                $this->config->load('tank_auth', TRUE);


        }

	/* $uri: with leading slash */

	function _purge_proxycache($uri)
	{

		$file = '/var/www/nginx_cache/' . md5($uri);

		if( file_exists( $file ))
			unlink( $file );

	}

	/**
	 * Show info message
	 *
	 * @param	string
	 * @return	void
	 */
	function _show_message($message, $modal = true, $refresh = false)
	{
		if($modal) {
			echo $message;
			return;
		}

		$this->load->view('auth/general_message', array('message' => $message, 'refresh' => $refresh ));
	}

	/**
	 * Send email message of given type (activate, forgot_password, etc.)
	 *
	 * @param	string
	 * @param	string
	 * @param	array
	 * @return	void
	 */
	function _send_email($type, $email, &$data, $subject = false, $from_email = false, $from_name = '', $cc='', $bcc='')
	{
		$this->load->library('email');
		if( $from_email ) {
			$this->email->from($from_email, $from_name);
			$this->email->reply_to($from_email, $from_name);
		} else {
	
			$this->email->from($this->config->item('webmaster_email', 'tank_auth'), $this->config->item('website_name', 'tank_auth'));
			$this->email->reply_to($this->config->item('webmaster_email', 'tank_auth'), $this->config->item('website_name', 'tank_auth'));
		}
		if( $cc )
			$this->email->cc($cc);
		if( $bcc )
			$this->email->bcc($bcc);
		$this->email->to($email);
		if( $subject )
			$this->email->subject($subject);
		else
			$this->email->subject(sprintf($this->lang->line('auth_subject_'.$type), $this->config->item('website_name', 'tank_auth')));


		if( $type ) {
			$this->email->message($this->load->view('email/'.$type.'-html', $data, TRUE));
			$this->email->set_alt_message($this->load->view('email/'.$type.'-txt', $data, TRUE));
		} else {
			$this->email->message($data);

		}
		$this->email->send();
	}


	/**
	 * Create CAPTCHA image to verify user as a human
	 *
	 * @return	string
	 */
	function _create_captcha()
	{
		$this->load->plugin('captcha');
		$this->load->library('encrypt');

		$cap = create_captcha(array(
			'img_path'		=> './'.$this->config->item('captcha_path', 'tank_auth'),
			'img_url'		=> base_url().$this->config->item('captcha_path', 'tank_auth'),
			'font_path'		=> './'.$this->config->item('captcha_fonts_path', 'tank_auth'),
			'font_size'		=> $this->config->item('captcha_font_size', 'tank_auth'),
			'img_width'		=> $this->config->item('captcha_width', 'tank_auth'),
			'img_height'	=> $this->config->item('captcha_height', 'tank_auth'),
			'show_grid'		=> $this->config->item('captcha_grid', 'tank_auth'),
			'expiration'	=> $this->config->item('captcha_expire', 'tank_auth'),
		));

		$cap['word'] = $this->encrypt->encode($cap['word']);
		$cap['time'] = $this->encrypt->encode($cap['time']);

		return $cap;
	}


	/**
	 * Callback function. Check if CAPTCHA test is passed.
	 *
	 * @param	string
	 * @return	bool
	 */
	function _check_captcha($code, $captcha_time, $captcha_word)
	{
		$this->load->library('encrypt');
		$time = $this->encrypt->decode($_POST['captcha_time']);
		$word = $this->encrypt->decode($_POST['captcha_word']);

		list($usec, $sec) = explode(" ", microtime());
		$now = ((float)$usec + (float)$sec);

		if ($now - $time > $this->config->item('captcha_expire', 'tank_auth')) {
			$this->form_validation->set_message('_check_captcha', $this->lang->line('auth_captcha_expired'));
			error_log( "Failed Captcha 1: $time - $now - $word - $code - " . 
				$_POST['email']  . " - " . 
				$_SERVER['REMOTE_ADDR']. " - " . 
				$_SERVER['HTTP_USER_AGENT'] );
			return FALSE;

		} elseif (($this->config->item('captcha_case_sensitive', 'tank_auth') AND
				$code != $word) OR
				strtolower($code) != strtolower($word)) {
			$this->form_validation->set_message('_check_captcha', $this->lang->line('auth_incorrect_captcha'));

			error_log( "Failed Captcha 2: $time - $now - $word - $code - " . 
				$_POST['email']  . " - " . 
				$_SERVER['REMOTE_ADDR']. " - " . 
				$_SERVER['HTTP_USER_AGENT'] );

			return FALSE;
		}
		return TRUE;
	}

	/**
	 * Create reCAPTCHA JS and non-JS HTML to verify user as a human
	 *
	 * @return	string
	 */
	function _create_recaptcha()
	{
		$this->load->helper('recaptcha');

		// Add custom theme so we can get only image
		$options = "<script>var RecaptchaOptions = {theme: 'custom', custom_theme_widget: 'recaptcha_widget'};</script>\n";

		// Get reCAPTCHA JS and non-JS HTML
		$html = recaptcha_get_html($this->config->item('recaptcha_public_key', 'tank_auth'));

		return $options.$html;
	}

	/**
	 * Callback function. Check if reCAPTCHA test is passed.
	 *
	 * @return	bool
	 */
	function _check_recaptcha()
	{
		$this->load->helper('recaptcha');

		$resp = recaptcha_check_answer($this->config->item('recaptcha_private_key', 'tank_auth'),
				$_SERVER['REMOTE_ADDR'],
				$_POST['recaptcha_challenge_field'],
				$_POST['recaptcha_response_field']);

		if (!$resp->is_valid) {
			$this->form_validation->set_message('_check_recaptcha', $this->lang->line('auth_incorrect_captcha'));
			return FALSE;
		}
		return TRUE;
	}



}
