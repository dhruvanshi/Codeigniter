<?php
	$address_field = array(
        'name'  => 'address',
        'value' => isset($result->address) ? $result->address : set_value('address')
    );
    $city_field = array(
        'name'  => 'city',
        'value' => isset($result->city)? $result->city : set_value('city')
    );
    /*For state option*/
    $state_options['0'] = '-- Select --';
    if(isset($state))
    {
        foreach($state as $state_data)
            $state_options[$state_data->abbreviation] = ucwords ($state_data->name);
    }
    $zip_field = array(
        'name'  => 'zipcode',
        'value' => isset($result->zipcode)? $result->zipcode : set_value('zipcode')
    );
    if(!empty($result->parking))
		$parking = explode('/',$result->parking);
	$parking_from = array(
		'name'  => 'parking_from',
		'value' => (!empty($result->parking))? $parking[0] : set_value('parking_from'),
		'class'	=> 'w70 txt-right'
	);
    $parking_to = array(
		'name'  => 'parking_to',
		'value' => (!empty($result->parking))? $parking[1] : set_value('parking_to'),
		'class'	=> 'w70 txt-right'
	);
    if(!empty($result->storage))
		$storage = explode('/',$result->storage);
    /*$storage_from = array(
		'name'  => 'storage_from',
		'value' => (!empty($result->storage))? $storage[0] : set_value('storage_from'),
		'class'	=> 'w70 txt-right'
	);
    $storage_to = array(
		'name'  => 'storage_to',
		'value' => (!empty($result->storage))? $storage[1] : set_value('storage_to'),
		'class'	=> 'w70 txt-right'
	*/
    $parking_prifix = array(
		'name'          =>  'parking_prifix',
		'value'         =>  (!empty($result->parking))? $parking[0] : set_value('parking_prifix'),
		'class'         =>  'w90 txt-right',
        'placeholder'   =>  'PC,PCI,HCP'
	);
    $parking_range = array(
		'name'          =>  'parking_range',
		'value'         =>  (!empty($result->parking))? $parking[1] : set_value('parking_range'),
		'class'     	=>  'w90 txt-right',
        'placeholder'   =>  '0-10,50-55,10'
	);
    $storage_prifix = array(
		'name'          =>  'storage_prifix',
		'value'         =>  (!empty($result->storage))? $storage[0] : set_value('storage_prifix'),
		'class'         =>  'w90 txt-right',
        'placeholder'   =>  'PC,PCI,HCP'
	);
    $storage_range = array(
		'name'          =>  'storage_range',
		'value'         =>  (!empty($result->storage))? $storage[1] : set_value('storage_range'),
		'class'     	=>  'w90 txt-right',
        'placeholder'   =>  '0-10,50-55,10'
	);
	$submit = array(
		'name' => 'submit',
		'value' => 'Save',
		'class' => 'btn btn-primary'
	);
	$cancel = array(
		'name' =>  'cancel',
		'value'=> 'cancel',
		'class'=> 'btn'
	);
?>
<div class="content">
    <div class="content-inner">
		<?php
			$attributes = array('class' => 'buildingfrm', 'id' => 'buildingfrm');
			echo form_open('building/operation/add',$attributes);
			echo form_hidden('building_id',isset($result->id) ? md5($result->id) : set_value('building_id'));
			echo form_hidden('project_id',isset($result->project_id) ? $result->project_id : set_value('project_id'));
		?>
		<div class="modal-header">
			<button type="button" class="close close-icon" data-dismiss="modal"><i class="icon-remove"></i></button>
            <h3>Building Detail</h3>
		</div>
        <div class="modal-body">
            <div class="span4 mrg0">
                <label>Address:</label>
                <?php echo form_input($address_field); ?>
                <div class="error">
                    <?php echo form_error('address'); ?>
                </div>
                <label>City:</label>
                <?php echo form_input($city_field); ?>
                <div class="error">
                    <?php echo form_error('city'); ?>
                </div>
                <label>State:</label>
                <?php echo form_dropdown('state', $state_options,isset($result->state) ? $result->state : set_value('state','CA')); ?>
                <div class="error">
                    <?php echo form_error('state'); ?>
                </div>
                <label>Zip Code:</label>
                <?php echo form_input($zip_field); ?>
                <div class="error">
                    <?php echo form_error('zipcode'); ?>
                </div>
            </div>
            <div class="span4">
                <label>Parking:</label>
                <div class="input-prepend">
                    <span class="add-on">Prefix:</span><?php echo form_input($parking_prifix); ?><span class="add-on">Range:</span><?php echo form_input($parking_range); ?>
                </div>
                <div class="error">
                    <?php echo form_error('parking_to'); ?>
                </div>
                <!--<div class="input-prepend">
                    <span class="add-on">P</span><?php //form_input($parking_from); ?><span> - </span><span class="add-on">P</span><?php //form_input($parking_to); ?>
                </div>
                <div class="error">
                    <?php //form_error('parking_to'); ?>
                </div>-->
                <label>Storage:</label>
                <div class="input-prepend">
                    <span class="add-on">Prefix:</span><?php echo form_input($storage_prifix); ?><span class="add-on">Range:</span><?php echo form_input($storage_range); ?>
                </div>
                <div class="error">
                    <?php echo form_error('parking_to'); ?>
                </div>
                <!--<div class="input-prepend">
                    <span class="add-on">S</span><?php //form_input($storage_from); ?><span> - </span><span class="add-on">S</span><?php //form_input($storage_to); ?>
                </div>	
                <div class="error">
                    <?php //form_error('storage_to'); ?>
                </div>-->
            </div>
            <div class="clear"></div>
        </div>
		<div class="modal-footer">
			<div class="pull-left">
                <?php echo form_submit($submit); ?><span class="mrgl10"><a href="#" class="btn" data-dismiss="modal">Cancel</a></span>
            </div>
		</div>
		<?php echo form_close(); ?>
	</div>
</div>