        <script>
            $(document).ready(function() {
                $.app.data_table.archive_project();
            });
        </script>        
        <div class="content">
        	<div class="content-inner">    
                <div class="row archive-alert alert alert-success <?php echo (!isset($status_messages['flash_success'])) ? 'hide' : '' ?>">
                	<button type="button" class="close">×</button>
					<span><?php echo (isset($status_messages['flash_success'])) ? $status_messages['flash_success'] : '' ?></span>                    
                </div> 
                <h3>Archive Project</h3>             
                <table cellpadding="0"  cellspacing="0" border="0" class="table table-striped " id="archive-project-listing">   
                    <thead>
                        <tr>
                            <th>Project_id</th>
                            <th>&nbsp;</th>
							<th>Project</th>
                            <th>Phase</th>                            
                            <th>Last Updated</th>                           
                            <th>Archived?</th>
                            <th>Action</th>                            
                        </tr>
                    </thead>
                    <tbody><tr><td colspan="6" class="tc">Loading Data...</td></tr></tbody>
                </table>
				<div id="overlay" class="hide overlay"></div>