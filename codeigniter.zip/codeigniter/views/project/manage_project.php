    <?php
	/* Project description option */	
	$name_field = array(
		'name'  => 'name',
		'value' => isset($result->name) ? $result->name : set_value('name')
	);
	$logo_field = array(
		'name'  => 'logo',
        'disabled' => 'disabled',
		'value' => isset($result->logo) ? $result->logo : set_value('logo'),
		'class'	=> 'input-small'
	);
    $desc_field = array(
		'name'  => 'description',
		'value' => isset($result->description) ? $result->description : set_value('description')
	);
	$phase_field = array(
		'name'  => 'phase',
		'value' => isset($result->phase) ? $result->phase : set_value('phase')
	);
	$commission_sales = array(
		'name'  => 'commission_sales',
        'class' => 'txt-right w185',
		'value' => isset($result->commission_sales) ? $result->commission_sales : set_value('commission_sales')
	);
    if(!empty($result->commission_ps))
            $com_ps = explode ('-', $result->commission_ps);
    $commission_ps = array(
		'name'  => 'commission_ps',
        'class' => 'txt-right w152',
		'value' => (!empty($result->commission_ps)) ? $com_ps[0] : set_value('commission_ps')
	);
    $commission_referral = array(
		'name'  => 'commission_referral',
        'class' => 'txt-right w185',
		'value' => isset($result->commission_referral) ? $result->commission_referral : set_value('commission_referral')
	);
    $commission_option = array(
		'%'  => '%',
		'$'  => '$'           
	);
	
    if(!empty($result->parking))
		$parking = explode('-',$result->parking);
	$parking_from = array(
		'name'  => 'parking_from',
		'value' => (!empty($result->parking))? $parking[0] : set_value('parking_from'),
		'class'	=> 'w70 txt-right'
	);
    $parking_to = array(
		'name'  => 'parking_to',
		'value' => (!empty($result->parking))? $parking[1] : set_value('parking_to'),
		'class'	=> 'w70 txt-right'
	);
    if(!empty($result->storage))
		$storage = explode('-',$result->storage);
    $storage_from = array(
		'name'  => 'storage_from',
		'value' => (!empty($result->storage))? $storage[0] : set_value('storage_from'),
		'class'	=> 'w70 txt-right',
	);    
    $storage_to = array(
		'name'  => 'storage_to',
		'value' => (!empty($result->storage))? $storage[1] : set_value('storage_to'),
		'class'	=> 'w70 txt-right'
	);        
	$submit = array(
		'name' => 'submit',
		'value' => 'Save',
		'id'	=>	'btn',
		'class' => 'btn btn-primary'
	);
    $submit_add = array(
		'name' => 'submit',
		'value' => 'Add',
		'id'	=>	'button',
		'class' => 'btn btn-primary'
	);
	$cancel = array(
		'name' =>  'cancel',
		'value'=> 'cancel',
		'class'=> 'btn'
	);
	/*project-logo pup-up*/	
	$logo_name = array(
		'name'  => 'logo_name',
        'disabled' => 'disabled',
		'value' => isset($result->logo) ? $result->logo:''
	);
	$logo_upload = array(
		'name' => 'userfile',
        'id'   => 'userfile'
	);
	$upload_btn = array(
		'name' => 'upload',
		'value' => 'Upload',
		'class'	=> 'btn'
    );
    
    $upload_save = array(
        'name'  => 'Save',
		'value' => 'Save',
        'id'    => 'logo-save',
		'class'	=> 'btn btn-primary'
    );
    
    $add_source	=	array(
		'name' => 'add_source',
		'value' =>  ''
	);
    /*$escrowc_option['0'] =	'-- Select --';
	if(isset($escrow))
	{
		foreach($escrow as $escrow_data)
			$escrowc_option[md5($escrow_data->id)] = ucwords($escrow_data->name);
	}*/
    $all_sourse_option = array();
    $select_sourse_option = array();
    
    if(isset($marketing_sources))
	{
        $marketing_source = unserialize($result->marketing_source);
        
		foreach($marketing_sources as $field)
        {   
            if($marketing_source)
            {
                if(in_array($field->id, $marketing_source))
                    $select_sourse_option[$field->id] = ucwords ($field->add_source);
                else
                    $all_sourse_option[$field->id] = ucwords ($field->add_source);
            }
            else
                $all_sourse_option[$field->id] = ucwords ($field->add_source);
        }
	}
    $project_option = array('-- Select --');
	if(isset($project))
	{
		foreach ($project as $field)
			$project_option[$field->id] = ($field->phase) ? ucwords ($field->name).' - PHASE '.$field->phase : ucwords ($field->name);
	}
    /*End for Project description field */	
?>
	<div class="content">
		<div class="content-inner">		
            <div class="row project-alert alert alert-success <?php echo (!isset($status_messages['flash_success'])) ? 'hide' : '' ?>">
                <button type="button" class="close">×</button>
				<span><?php echo (isset($status_messages['flash_success'])) ? $status_messages['flash_success'] : '' ?></span>
            </div>
			<div class="row mrg0 heading">
				<h3 class="pull-left">Project Detail</h3>
				<div class="pull-right project-logo <?php echo (isset($result->logo) && !empty($result->logo)) ? '' : 'hide'?>">
				<img src="<?php echo site_url()?>assets/uploads/<?php echo (isset($result->logo) && !empty($result->logo)) ? $result->logo : '';?>" id="project-logo" alt="<?php echo ucwords($result->name);?> Logo" style="max-width:75px;max-height: 50px;" title="<?php echo ucwords($result->name);?> Logo" />
				</div>
			</div>
			<div class="clear"></div>
			<!--Start Tabs -->
            <ul class="nav nav-tabs" id="project-tab">
                <li class="active"><a id="project-desc"href="#proj-description" data-toggle="tab">Description</a></li>
                <li><a href="#building" id="building-tab" data-toggle="tab">Buildings</a></li>
                <!--<li><a href="#floor-plan" id="floorplan-tab" data-toggle="tab">Floorplans</a></li>-->
                <li><a href="#parking" id="parking-tab" data-toggle="tab">Parking</a></li>
                <li><a href="#storage" id="storage-tab" data-toggle="tab">Storage</a></li>
                <li><a href="#access" id="access-tab" data-toggle="tab">Access</a></li>
				<li><a href="#marketing_sources" id="marketing-tab" data-toggle="tab">Marketing Sources</a></li>
                <?php
                    if(!empty($result->building)):
                        foreach($result->building as $building):
                            $address_length = (strlen($building->address)> 15 ) ? substr($building->address,0,15) : $building->address;
                            $filter_address = preg_replace('/[^a-zA-Z0-9]/s', '-', $address_length);
                ?>
                <li  id="<?php echo $filter_address.'-li-tab' ?>" class="unit-li-tab"><a href="#<?php echo $filter_address.'-tab' ?>" rel="<?php echo md5($building->id) ?>" data-toggle="tab"><?php echo ucwords($building->address) ?></a></li>
                <?php
                        endforeach;
                    endif;
                ?>
            </ul>
			<!--End Tabs -->
			<!-- Start Tab-Content -->
			<div class="tab-content">
				<!-- Start project description Tab -->
				<div class="tab-pane active" id="proj-description" >
					<?php
						$attributes = array('class' => 'proj-descfrm', 'id' => 'proj-descfrm');
						echo form_open('project/operation/add',$attributes);
						echo form_hidden('project_id',isset($result->id) ? md5($result->id) : set_value('project_id'));
					?>
					<div class="span4 mrg0">
						<label>Project Name:</label>
                        <?php echo form_input($name_field); ?>
						<div class="error">
                            <?php echo form_error('name'); ?>
						</div>
						<label>Project Logo:</label>
                        <?php echo form_input($logo_field); ?><span>  <a class="logo-modal" id="logo-modal"  href="javascript:void(0);">Upload Project Logo</a></span>
						<div class="error">
							<?php echo form_error('logo'); ?>
						</div>
                        <label>Project Description:</label>
						<?php echo form_textarea($desc_field); ?>
						<div class="error">
                            <?php echo form_error('description'); ?>
						</div>
					</div>
					<div class="span4">
						<label>Phase:</label>
						<?php echo form_input($phase_field); ?>
						<div class="error">
							<?php echo form_error('phase'); ?>
						</div>
						<label>Commission on Sales Price:</label>
                        <div class="input-append">
                            <?php echo form_input($commission_sales); ?><span class="add-on">&#37;</span>
                            <div class="error">
								<?php echo form_error('commission_sales'); ?>
                            </div>
                        </div>
						
                        <label>Parking &amp; Storage Commission:</label>
						<div class="input-append">
                            <?php echo form_input($commission_ps); ?><span><?php echo form_dropdown('commission_opt', $commission_option, (!empty($result->commission_ps)) ? $com_ps[1] : set_value('commission_opt',$this->input->post('commission_opt')),'class="span1"'); ?></span>
                            <div class="error">
								<?php echo form_error('commission_ps'); ?>
                            </div>
                        </div>
						
                        <label>Referral Commission:</label>
						<div class="input-append">
                            <?php echo form_input($commission_referral); ?><span class="add-on">&#37;</span>
                            <div class="error">
								<?php echo form_error('commission_referral'); ?>
                            </div>
                        </div>
					</div>
					<div class="clear"></div>
					<div class="span4 mrg0">
                        <label>&nbsp;</label>
						<?php echo form_submit($submit); ?>
						<?php echo anchor(base_url().'project','Cancel','class="btn"'); ?>
						<?php echo form_close(); ?>
                    </div>
				</div>
				<!-- End project description Tab -->
                <!-- Start building Tab -->
                <div class="tab-pane" id="building">
                    <div class="create-link"><a href="javascript:void(0);" class="add-building" rel="<?php echo $result->id;?>">Add Building</a></div>
                    <!-- start Display Data of Building -->
                    <table cellpadding="0"  cellspacing="0" border="0" class="table table-striped" id="building-listing">
                        <thead>
                            <tr>
                            	<th>Building_id</th>
                                <th>Address</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Zip</th>
                                <th>Parking</th>
                                <th>Storage</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody><tr><td colspan="6" class="tc">Loading Data...</td></tr></tbody>
                    </table>
					<!-- End Display Data of Building -->
                </div>
                <!-- End Building Tab -->
                <!-- start floorpaln Tab -->
                <!--<div class="tab-pane" id="floor-plan">
                    <div class="create-link">
						<a href="javascript:void(0);" class="add-floorplan" rel="<?php echo $result->id; ?>">Add Floorplan</a>
						<div class="pull-right">
							<a href="javascript:void(0);" role="button" class="copy-floorplan btn" rel="<?php echo $result->id; ?>">Copy Floorplan</a>
						</div>
					</div>
                    <!-- start Display Data of Floor plan -->
                    <!--<table cellpadding="0"  cellspacing="0" border="0" class="table table-striped" id="floorplan-listing">   
                        <thead>
                            <tr>
                                <th>Floor plan_id</th>
                                <th>Floorplan</th>
                                <th>Bed</th>
                                <th>Bath</th>
                                <th>Sq Ft</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody><tr><td colspan="7" class="tc">Loading Data...</td></tr></tbody>
                    </table>-->
					<!-- End Display Data of Floor plan -->
                <!--</div>-->
                <!-- end floorpaln Tab -->
                <!-- start parking Tab -->
                <div class="tab-pane" id="parking">
                    <label>Show Parking for:</label>
                    <?php echo form_dropdown('select_building',array('0'=>'-- Select --'),'','id="parking-building"'); ?>
                    <div class="create-link"><a href="javascript:void(0);" class="custom-parking hidden">Add Custom Parking Space</a></div>
                    <table cellpadding="0"  cellspacing="0" border="0" class="table table-striped hidden" id="parking-listing">
                        <thead>
                            <tr>
                                <th>Parking_id</th>
                                <th>Space</th>
                                <th>Type</th>
                                <th>Price</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody><tr><td colspan="5" class="tc">Loading Data...</td></tr></tbody>
                    </table>
                </div>
                <!-- end parking Tab -->
                <!-- start storage Tab -->
                <div class="tab-pane" id="storage">
                    <label>Show Storage for:</label>
                    <?php echo form_dropdown('select_building',array('0'=>'-- Select --'),'','id="storage-building"'); ?>
                    <div class="create-link"><a href="javascript:void(0);" class="custom-storage hidden">Add Custom Storage Space</a></div>
                    <table cellpadding="0"  cellspacing="0" border="0" class="table table-striped hidden" id="storage-listing">
                        <thead>
                            <tr>
                                <th>Storage_id</th>
                                <th>Space</th>
                                <th>Type</th>
                                <th>Price</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody><tr><td colspan="5" class="tc">Loading Data...</td></tr></tbody>
                    </table>
                </div>
                <!-- end storage Tab -->
                <!-- start access Tab -->
                <div class="tab-pane" id="access">
                    <div class="span8 mrg0">
                        Add users to the project by clicking the Add button. Only users assigned to a
                        project can view the project details.&nbsp;(Polaris users can view all 
                        projects.)
                    </div>
                    <div class="clear"></div>
                    <?php
                        $all_extra = 'id="all-user" size="4"';
                        $selected_extra = 'id="selected-user" size="4"';
                    ?>
                    <div class="span3 mrg0 mrgt20">
                        <h4>All Users</h4>   
                        <?php echo form_dropdown('all_user',array(),'',$all_extra) ?>
                    </div>
                    <div class="span2 mrgt20 acces-btn">
                        <p><a href="javascript:void(0);" id='btn-right' class="btn"><i class="icon-arrow-right"></i></a></p>
                        <p>&nbsp;</p>
                        <p><a href="javascript:void(0);" id='btn-left' class="btn"><i class="icon-arrow-left"></i></a></p>
                    </div>
                    <div class="span3 mrg0 mrgt20">
                        <h4>Selected Users</h4>   
                        <?php echo form_dropdown('selected_user',array(),'',$selected_extra) ?>
                    </div>
                </div>
                <!-- end access Tab -->
                <!-- start marketing sources Tab -->
				<div class="tab-pane" id="marketing_sources">
                    <?php
						$attributes = array('class' => 'proj-marketing', 'id' => 'proj-marketing');
						echo form_open('project/operation/market_source',$attributes);
						echo form_hidden('project_id',isset($result->id) ? md5($result->id) : set_value('project_id'));
					?>
                    <div class="span3 mrg0 mrgt20">
                        <h4><a href="javascript:void(0)" class="sorting all-sorting sorting-icon"> All Source</a></h4>
                        <?php echo form_multiselect('all_source',$all_sourse_option,'','id="all-source" size="6"') ?>
                    </div>
                    <div class="span2 mrgt20 acces-btn">
                        <p><a href="javascript:void(0);" id='btn-right-source' class="btn"><i class="icon-arrow-right"></i></a></p>
                        <p class="mrgt10"><?php if($this->session->userdata('user_role') == 1): ?><a href="javascript:void(0);" id='btn-delete-source' class="btn"><i class="icon-trash"></i></a><?php else: echo '<br />'; endif; ?></p>
                        <p class="mrgt10"><a href="javascript:void(0);" id='btn-left-source' class="btn"><i class="icon-arrow-left"></i></a></p>
                    </div>
                    <div class="span3 mrg0 mrgt20">
                        <h4><a href="javascript:void(0)" class="sorting select-sorting sorting-icon"> Selected Source </a></h4>
                        <?php echo form_multiselect('selected_source',$select_sourse_option,'','id="selected-source" size="6"') ?>
                    </div>
                    <div class="clear"></div>
                    <label>Add Source:</label>
                    <?php echo form_input($add_source); ?>
                    <div class="error">
                        <?php echo form_error(); ?>
                    </div>
                    <div class="span4 mrg0">
                        <?php echo form_submit($submit_add); ?>
						<?php echo form_close(); ?>
                    </div> 
                </div>
                <!-- end marketing sources Tab -->
                <!-- start dynamic building Tab -->
                <?php
                    if(!empty($result->building)):
                        foreach($result->building as $building):
                            $filter_address = preg_replace('/[^a-zA-Z0-9]/s', '-', $building->address);
                            $filter_address = (strlen($filter_address)> 15 ) ? substr($filter_address,0,15) : $filter_address; 
                ?>
                <div class="tab-pane" id="<?php echo $filter_address.'-tab' ?>"><?php echo $building->address ?></div>
                <?php
                        endforeach;
                    endif;
                ?>
                <!-- end dynamic building Tab -->
			</div>
			<!-- End Tab Project -->
			<div class="clear"></div>
			
			<div class="modal hide fade" id="new-company" >
			</div>
            <div class="modal hide fade" id="proj-building" >
			</div>
            <div class="modal hide fade" id="proj-floorplan" >
			</div>
            <div class="modal hide fade" id="proj-view" >
			</div>
            <div class="modal hide fade" id="proj-parking" >
			</div>
            <div class="modal hide fade" id="proj-storage" >
			</div>
            <div class="modal hide fade" id="proj-unit" >
			</div>
            <!-- Listing for building unit -->
            <div class="hide" id="building-unit">
                <div class="create-link"><?php echo anchor('javascript:void(0);','Add Unit',array('class' => 'add-unit','data-id'=>$result->id,'rel'=>$result->id)); ?></div>
                <!-- start Display Data of building unit -->
                <table cellpadding="0"  cellspacing="0" border="0" class="table table-striped unit-listing">   
                    <thead>
                        <tr>
                            <th>Unit_id</th>
                            <th>Unit</th>
                            <th>Plan</th>
                            <th>Floor</th>
                            <th>Price</th>
                            <th>Parking</th>
							<th>Square Footage</th>
                            <th>Storage</th>
                            <th>Escrow#</th>
                            <th>On Market</th>
                            <th>Holdback</th>
                            <th>Model</th>
                            <th>BMR</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody><tr><td colspan="15" class="tc">Loading Data...</td></tr></tbody>
                </table>
                <!-- End Display Data of building unit -->
            </div>

            <div class="modal hide fade" id="new-logo" >
				<?php 
					$attributes = array('class' => 'proj-logofrm', 'id' => 'proj-logofrm');
					echo form_open_multipart('project/do_upload',$attributes);
					echo form_hidden('old_logo',isset($result->logo) ? ($result->logo) : set_value('old_logo'));
				?>
				<div class="modal-header">
					<button type="button" class="close close-icon" data-dismiss="modal"><i class="icon-remove"></i></button>
					<h3>Project Logo</h3>
				</div>
                <div class="modal-body">
					<div class="span8 logo-mrg">
						<p class="span6 mrgt20">Use the Browse and Upload buttons to upload a project logo. If the Logo File Name is empty, the Polaris Logo will be used.</p>
						<div class="clear"></div>
						<div class="span5 mrgt20">
							<label>Logo File Name:</label>
							<?php echo form_input($logo_name); ?>
							<span class="mrgl10"><a class="remove-logo" id="remove-logo" href="javascript:void(0);">Remove Project Logo</a></span>
							<div class="clear"></div>
							<label>Upload New Logo:</label>
							<?php echo form_upload($logo_upload);?>
							<div class="error">
								<?php echo form_error('userfile'); ?>
							</div>
							<div class="mrgt20">
								<?php echo form_submit($upload_btn); ?><img class="upload-process hide" src="<?php echo base_url();?>assets/img/ajax-loader.gif" alt="Processing" />
							</div>
						</div>
						<div class="span3 mrg0 image hidden">
							<img src="" class="show-image" width="200" height="200" />
						</div>
					</div>
					<div class="clear"></div>
            	</div>
				<div class="modal-footer">
					<div class="pull-left">
						<?php echo form_button($upload_save,'Save'); ?><span class="mrgl10"><a href="#" class="btn" data-dismiss="modal">Cancel</a></span>
					</div>
				</div>
				<?php echo form_close(); ?>
			</div>
			<div class="modal hide fade" id="escrow-contact" ></div>
            <div class="overlay hide" id="overlay"></div>
			<div class="modal hide fade" id="copy-floorplan">
				<?php 
					$attributes = array('class' => 'copy-floorplanfrm', 'id' => 'copy-floorplanfrm');
					echo form_open_multipart('project/copy_floorplan',$attributes);
					echo form_hidden('project_id',isset($result->id) ? md5($result->id) : set_value('project_id'));
				?>
				<div class="modal-header">
					<button type="button" class="close close-icon" data-dismiss="modal"><i class="icon-remove"></i></button>
					<h3>Copy Floorplan</h3>
				</div>
            	<div class="modal-body">
                    <div class="span5 mrgt20">
                    	<label>Project Name:<label>
                        <?php echo form_dropdown('project',$project_option); ?>
                    </div>
                    <div class="clear"></div>
                    <div class="span3 mrg0 mrgt20">
                        <h4>All Floorplan</h4>   
                        <?php echo form_multiselect('all_floorplan',array(),'','id="all_floorplan" size="4"') ?>
                    </div>
                    <div class="span2 mrgt20 acces-btn">
                        <p><a href="javascript:void(0);" id='btn-right-floorplan' class="btn"><i class="icon-arrow-right"></i></a></p>
                        <p>&nbsp;</p>
                        <p><a href="javascript:void(0);" id='btn-left-floorplan' class="btn"><i class="icon-arrow-left"></i></a></p>
                    </div>
                    <div class="span3 mrg0 mrgt20">
                        <h4>Copy Floorplan</h4>   
                        <?php echo form_multiselect('selected_floorplan',array(),'','id="select_floorplan" size="4"') ?>
                    </div>
                    <div class="clear"></div>
            	</div>
				<div class="modal-footer">
					<div class="pull-left">
                    	<?php echo form_submit(array('name'=>'submit','value'=>'Copy','class'=>'btn btn-primary')); ?><span class="mrgl10"><a href="#" class="btn" data-dismiss="modal">Cancel</a></span>
                    	<?php echo form_close(); ?>
                    </div>
				</div>
				<div class="clear"></div>
			</div>