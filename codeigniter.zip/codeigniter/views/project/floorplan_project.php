<?php
	$name_field = array(
        'name'  => 'name',
        'value' => isset($result->name) ? $result->name : set_value('name')
    );
    $bedroom_field = array(
        'name'  => 'bedroom',
        'value' => isset($result->bedroom)? $result->bedroom : set_value('bedroom'),
        'class'	=> 'txt-right'
    );
    $bathroom_field = array(
        'name'  => 'bathroom',
        'value' => isset($result->bathroom)? $result->bathroom : set_value('bathroom'),
        'class'	=> 'txt-right'
    );
    $hoa_dues = array(
        'name'  => 'hoa_dues',
        'value' => isset($result->hoa_dues)? $result->hoa_dues : set_value('hoa_dues'),
    );
    $square_field = array(
        'name'  => 'square_feet',
        'value' => isset($result->square_feet)? $result->square_feet : set_value('square_feet'),
        'class'	=> 'txt-right'
    );
	$submit = array(
		'name' => 'submit',
		'value' => 'Save',
		'class' => 'btn btn-primary'
	);
	$cancel = array(
		'name' =>  'cancel',
		'value'=> 'cancel',
		'class'=> 'btn'
	);		
?>
<div class="content">
    <div class="content-inner">
		<?php
			$attributes = array('class' => 'floorplanfrm', 'id' => 'floorplanfrm');
			echo form_open('floorplan/operation/add',$attributes);
			echo form_hidden('floorplan_id',isset($result->id) ? md5($result->id) : set_value('floorplan_id'));
			echo form_hidden('project_id',isset($result->project_id) ? $result->project_id : set_value('project_id'));
		?>
		<div class="modal-header">
			<button type="button" class="close close-icon" data-dismiss="modal"><i class="icon-remove"></i></button>
            <h3>Floorplan Detail</h3>
		</div>
        <div class="modal-body">
            <div class="span4 mrg0">
                <label>Floorplan name:</label>
                <?php echo form_input($name_field); ?>
                <div class="error">
                    <?php echo form_error('name'); ?>
                </div>
                <label>&#35; of Bedrooms:</label>
                <?php echo form_input($bedroom_field); ?>
                <div class="error">
                    <?php echo form_error('bedroom'); ?>
                </div>
                <label>&#35; of Bathrooms:</label>
                <?php echo form_input($bathroom_field); ?>
                <div class="error">
                    <?php echo form_error('bathroom'); ?>
                </div>
            </div>
            <div class="span4">
                <!--<label>&#35; of Parking Spaces:</label>
                <?php //form_input($parking_field); ?>
                <div class="error">
                    <?php //form_error('parking_space'); ?>
                </div>-->
                <label>Square Feet:</label>
                <?php echo form_input($square_field); ?>
                <div class="error">
                    <?php echo form_error('square_feet'); ?>
                </div>
                <label>HOA Dues</label>
                <?php echo form_input($hoa_dues); ?>
                <div class="error">
                    <?php echo form_error('hoa_dues');?>
                </div>
            </div>
            <div class="clear"></div>       	
        </div>
		<div class="modal-footer">
            <div class="pull-left">
				<?php echo form_submit($submit); ?><span class="mrgl10"><a href="#" class="btn" data-dismiss="modal">Cancel</a></span>
            </div>
		</div>
		<?php echo form_close(); ?>
	</div>
</div>