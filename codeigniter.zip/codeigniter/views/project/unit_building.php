<?php		
    $unit_number = array(
        'name'	=> 'unit_number',
		'value'	=>	isset($result->unit_number) ? $result->unit_number : set_value('unit_number')
    );
    $floorplan_option['0'] = '-- Select --';
	if(!empty($floorplan))
	{
		foreach($floorplan as $floorplan_data)
			$floorplan_option[$floorplan_data->id] = ucwords($floorplan_data->name);
	};
    $floor_field = array(
        'name'  => 'floor',
        'value' => isset($result->floor) ? $result->floor : set_value('floor')
    );
	/*$view_option['0'] =	'-- Select --';
	if(!empty($project_view))
	{
		foreach($project_view as $view_data)
			$view_option[$view_data->id] = ucwords($view_data->view);
	};*/
	$parking_option['0'] =	'-- Select --';
	if(!empty($project_parking))
	{
		foreach($project_parking as $parking_data)
		{
			$parking_option[$parking_data->id] = strtoupper($parking_data->type_name).$parking_data->space;
		}
	};
	$storage_option['0'] =	'-- Select --';
	if(!empty($project_storage))
	{
		foreach($project_storage as $storage_data)
		{
            $storage_option[$storage_data->id] = strtoupper($storage_data->type_name).$storage_data->space;
			/*if(is_numeric($storage_data->space))
				$storage_option[$storage_data->id] = ucwords('S'.$storage_data->space);
			else
				$storage_option[$storage_data->id] = ucwords($storage_data->space);*/
		}
	};
	$exterior_yes = array(
		'name'        => 'exterior',
		'id'          => 'exterior_yes',
		'value'       => '1',
		'checked'	  => isset($result->exterior) ? ($result->exterior == 1) ? 'checked': '' : ''
	);
	$exterior_no = array(
		'name'        => 'exterior',
		'id'          => 'exterior_no',
		'value'       => '0',
		'checked'	  => isset($result->exterior) ? ($result->exterior == 0) ? 'checked' : '' : 'checked'
	); 
	$exterior_space = array(
		'name' => 'exterior_space',
		'value' => isset($result->exterior_space) ? $result->exterior_space : set_value('exterior_space')
	);
	$price_field = array(
		'name'	=> 'price',
		'value' => isset($result->price) ? $result->price : set_value('price'),	
		'class'	=> 'txt-right'
	);
	$holdback_yes = array(
		'name'        => 'holdback',
		'id'          => 'holdback_yes',
		'value'       => '1',
		'checked'	  => isset($result->holdback) ? ($result->holdback == 1) ? 'checked': '' : ''
	);
	$holdback_no = array(
		'name'        => 'holdback',
		'id'          => 'holdback_no',
		'value'       => '0',
		'checked'	  => isset($result->holdback) ? ($result->holdback == 0) ? 'checked' : '' : 'checked'
	); 
	$sales_office_yes = array(
		'name'        => 'sales_office',
		'id'          => 'sales_office_yes',
		'value'       => '1',
		'checked'	  => isset($result->sales_office) ? ($result->sales_office == 1) ? 'checked': '' : ''
	);
	$sales_office_no = array(
		'name'        => 'sales_office',
		'id'          => 'sales_office_no',
		'value'       => '0',
		'checked'	  => isset($result->sales_office) ? ($result->sales_office == 0) ? 'checked' : '' : 'checked'	
	);
	$escrow_number = array(
		'name' => 'escrow_number',
		'value' => isset($result->escrow_number) ? $result->escrow_number : set_value('escrow_number')
	);
	$bmr_yes = array(
		'name'        => 'bmr',
		'id'          => 'bmr_yes',
		'value'       => '1',
		'checked'	  => isset($result->bmr) ? ($result->bmr == 1) ? 'checked': '' : ''
	);
	$bmr_no = array(
		'name'        => 'bmr',
		'id'          => 'bmr_no',
		'value'       => '0',
		'checked'	  => isset($result->bmr) ? ($result->bmr == 0) ? 'checked' : '' : 'checked'
	); 
	$model_yes = array(
		'name'        => 'model_unit',
		'id'          => 'model_yes',
		'value'       => '1',
		'checked'	  => isset($result->model_unit) ? ($result->model_unit == 1) ? 'checked': '' : ''
	);
	$model_no = array(
		'name'        => 'model_unit',
		'id'          => 'model_no',
		'value'       => '0',
		'checked'	  => isset($result->model_unit) ? ($result->model_unit == 0) ? 'checked' : '' : 'checked'
	); 
	$released_tomarket = array(
		'name' 	=> 'market_release',
		'value' => isset($result->market_release) ? $result->market_release : set_value('market_release'),
		'class'	=>	'datepicker'	
	);
	$submit = array(
		'name' => 'submit',
		'value' => 'Save',
		'class' => 'btn btn-primary'
	);
	$parking_addtional_space = array(
        'name'  => 'parking_addtional_space',
        'disabled' => 'disabled',
        'value' => isset($result->parking_addtional_space) ? $result->parking_addtional_space : set_value('parking_addtional_space')
    );
	$storage_addtional_space = array(
        'name'  => 'storage_addtional_space',
        'disabled' => 'disabled',
        'value' => isset($result->storage_addtional_space) ? $result->storage_addtional_space : set_value('storage_addtional_space')
    );
	$cancel = array(
		'name' =>  'cancel',
		'value'=> 'cancel',
		'class'=> 'btn'
	);		
?>
<div class="content">
    <div class="content-inner">
		<?php
			$attributes = array('class' => 'unitfrm', 'id' => 'unitfrm');
			echo form_open('unit/operation/add',$attributes);
			echo form_hidden('project_id');
			echo form_hidden('unit_id',isset($result->id) ? md5($result->id) : set_value('unit_id'));
			echo form_hidden('building_id',isset($result->building_id) ? md5($result->building_id) : set_value('building_id'));
		?>
		<div class="modal-header">
			<button type="button" class="close close-icon" data-dismiss="modal"><i class="icon-remove"></i></button>
            <h3>Unit Detail</h3>
		</div>
        <div class="modal-body">
            <div class="span4 mrg0">
                <label>Unit Number:</label>
                <?php echo form_input($unit_number) ?>
                <div class="error">
                    <?php echo form_error('unit_number'); ?>
                </div>
                
				<label>Floor:</label>
                <?php echo form_input($floor_field) ?>
                <div class="error">
                    <?php echo form_error('floor'); ?>
                </div>            
                
				<label>Parking Space:</label>
                <?php echo form_dropdown('project_parking', $parking_option, isset($result->project_parking) ? $result->project_parking : ''); ?>
                <div class="error">
                    <?php echo form_error('project_parking'); ?>
                </div>        
                
				<div class="additional-space-parking <?php echo empty($result->parking_addtional_space) ? 'hide' : ''?>">
                    <label>Parking Additional Space:</label>
                    <?php echo form_input($parking_addtional_space) ?>
                    <div class="error">
                        <?php echo form_error('parking_addtional_space'); ?>
                    </div>
                </div>
                
				<label>Has Exterior Space:<?php echo form_radio($exterior_yes). ' Yes';?><?php echo form_radio($exterior_no).' No'; ?> </label>
                <div class="error">
                    <?php echo form_error('exterior'); ?>
                </div>
                
				<label>Exterior Space:</label>
                <?php echo form_input($exterior_space); ?>
                <div class="error">
                    <?php echo form_error('exterior_space'); ?>
                </div> 

                <label>Floorplan:</label>
                <?php echo form_dropdown('floorplan', $floorplan_option, isset($result->floorplan) ? $result->floorplan : ''); ?>
                <div class="error">
                    <?php echo form_error('floorplan'); ?>
                </div>
                <a href="javascript:void(0);" class="add-floorplan">Add Floorplan</a>
				
				<label>Square Footage:</label>
				<?php echo form_input('square_footage',isset($result->square_footage) ? $result->square_footage : ''); ?>
				<div class="error">
					<?php echo form_error('square_footage'); ?>
				</div>
            </div>
            <div class="span4 mrg0">
                
				<label>Escrow Number:</label>
                <?php echo form_input($escrow_number); ?>
                <div class="error">
                    <?php echo form_error('escrow_number'); ?>
                </div> 
                
                <label>Storage Space:</label>
                <?php echo form_dropdown('project_storage', $storage_option, isset($result->project_storage) ? $result->project_storage : ''); ?>
                <div class="error">
                    <?php echo form_error('project_storage'); ?>
                </div>       
                
				<div class="additional-space-storage <?php echo empty($result->storage_addtional_space) ? 'hide' : ''?>">
                    <label>Storage Additional Space:</label>
                    <?php echo form_input($storage_addtional_space) ?>
                    <div class="error">
                        <?php echo form_error('storage_addtional_space'); ?>
                    </div>
                </div>			
                
				<label>Price:</label>
                <?php echo form_input($price_field); ?>
                <div class="error">
                    <?php echo form_error('price'); ?>
                </div>                                  
                
				<label class="pad0 radio inline">Developer Holdback:</label>
				<label class="radio inline"> <?php echo  form_radio($holdback_yes); ?>Yes </label>
				<label class="radio inline"> <?php echo  form_radio($holdback_no); ?>No </label>
				<div class="error">
                    <?php echo form_error('holdback'); ?>
                </div>           
                
				<label class="pad0 radio inline">BMR:</label>
				<label class="radio inline"> <?php echo  form_radio($bmr_yes); ?>Yes </label>
				<label class="radio inline"> <?php echo  form_radio($bmr_no); ?>No </label>
				<div class="error">
                    <?php echo form_error('bmr'); ?>
                </div>
                
				<label class="pad0 radio inline">Model Unit:</label>
				<label class="radio inline"> <?php echo  form_radio($model_yes); ?>Yes </label>
				<label class="radio inline"> <?php echo  form_radio($model_no); ?>No </label>
                <div class="error">
                    <?php echo form_error('model_unit'); ?>
                </div>
                
				<label class="pad0 radio inline">Sales Office:</label>
				<label class="radio inline"> <?php echo  form_radio($sales_office_yes); ?>Yes </label>
				<label class="radio inline"> <?php echo  form_radio($sales_office_no); ?>No </label>
                <div class="error">
                    <?php echo form_error('model_unit'); ?>
                </div>

				<label>Released to Market:</label>
                <?php echo form_input($released_tomarket); ?>
                <div class="error">
                    <?php echo form_error('market_release'); ?>
                </div>
            </div>
            <div class="clear"></div>
        </div>
		<div class="modal-footer">
            <div class="pull-left">
                <?php echo form_submit($submit); ?><span class="mrgl10"><a href="#" class="btn" data-dismiss="modal">Cancel</a></span><span class="mrgl10"><a href="#" class="btn btn-primary add-another-unit">Save and Add Another Unit</a></span>
            </div>
		</div>
		<?php echo form_close(); ?>
	</div>
</div>