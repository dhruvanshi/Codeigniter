<?php
	$project_name = array(
		'name'  => 'project_name',
		'value' => isset($result->name) ? $result->name:set_value('project_name')
	);
    $phase_name = array(
		'name'  => 'phase',
		'value' => set_value('phase_name'),
	);
	$submit = array(
		'name' => 'submit',
		'value' => 'Save',
		'class' => 'btn btn-primary'
	);
	$cancel = array(
		'name' =>  'cancel',
		'value'=> 'cancel',
		'class'=> 'btn'
	);	
	$url = isset($_SERVER["HTTP_REFERER"]) ? $_SERVER["HTTP_REFERER"] : base_url();
?>
<div class="content">
    <div class="content-inner">        
        <div class="alert alert-success <?php echo (!isset($status_messages['flash_success'])) ? 'hide' : '' ?>">
            <span><?php echo (isset($status_messages['flash_success'])) ? $status_messages['flash_success'] : '' ?></span>
            <button type="button" class="close" data-dismiss="alert">×</button>
        </div>
        <?php
            $attributes = array('class' => 'add-projectfrm', 'id' => 'add-projectfrm');
            echo form_open('project/operation/add-project',$attributes);
			echo form_hidden('project_id',isset($result->id) ? md5($result->id) : set_value('project_id'));
        ?>
        <div class="span6 mrg0">
        	<?php if(isset($result->name) || isset($project_id)){
            	echo form_hidden('project_name',isset($result->name) ? $result->name : set_value('project_name'));?>
            	<h3>Create New Phase:</h3>
                <div>
                	<p>To create a new phase, enter the new phase number and press Create Phase.
                    All floorplans, views, and project members will be copied to the new phase.
                    Buildings and units will not be copied.</p>
                </div>
               	<div class="mrgt20">
                    <label>Project:<strong>   <?php echo isset($result->name) ? $result->name : $project ; ?></strong></label>
                    <label>Phase:</label>
                    <?php echo form_input($phase_name); ?>
                    <div class="error">
                        <?php echo form_error('phase_name'); ?>
                    </div>
				</div>
            <?php }else{ ?>
				<h3>Project Details:</h3>
				<label>Project:</label>
                <?php echo form_input($project_name); ?>
				<div class="error">
					<?php echo form_error('project_name'); ?>
				</div>
			<?php } ?>
            <label>&nbsp;</label>
            <?php echo form_submit($submit); ?>
            <?php echo anchor($url,'Cancel','class="btn"'); ?>
            <?php echo form_close(); ?>
        </div>
        <div class="clear"></div>