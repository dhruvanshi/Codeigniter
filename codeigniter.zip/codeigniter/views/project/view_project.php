<?php
	$view_field = array(
        'name'  => 'view',
        'value' => isset($result->view) ? $result->view : set_value('view'),
    );
    
	$submit = array(
		'name' => 'submit',
		'value' => 'Save',
		'class' => 'btn btn-primary'
	);
	$cancel = array(
		'name' =>  'cancel',
		'value'=> 'cancel',
		'class'=> 'btn'
	);		
?>
<div class="content">
    <div class="content-inner">
        <button type="button" class="close close-icon" data-dismiss="modal"><i class="icon-remove"></i></button>
        <div class="span12 mrg0"><h3>View Detail</h3></div>
        <?php
            $attributes = array('class' => 'viewfrm', 'id' => 'viewfrm');
            echo form_open('view/operation/add',$attributes);
            echo form_hidden('view_id',isset($result->id) ? md5($result->id) : set_value('view_id'));
            echo form_hidden('project_id',isset($result->project_id) ? $result->project_id : set_value('project_id'));
        ?>
        <div class="span4 mrg0">
            <label>View:</label>
            <?php echo form_input($view_field); ?>
            <div class="error">
                <?php echo form_error('view'); ?>
            </div>
        </div>
        <div class="clear"></div>
        <div class="span4 mrg0">
           <label>&nbsp;</label>
           <?php echo form_submit($submit); ?><span class="mrgl10"><a href="#" class="btn" data-dismiss="modal">Cancel</a></span>
           <?php echo form_close(); ?>
        </div>    

        <div class="clear"></div>       	