<?php	
    $storage_option = array(
        1 =>'Assigned',
        2 =>'Additional',
        3 =>'N/A'
    );
    $space_field = array(
        'name'  => 'space',
        'value' => isset($result->space) ? $result->space : set_value('space')
    );
	$extra_space_yes = array(
		'name'		=>	'extra_space',
		'id'    	=> 	'extra_space_yes',
		'value'  	=> 	'1',
		'checked'	=> 	isset($result->addtional_space) ? 'checked': ''
	);
	$extra_space_no = array(
		'name'		=>	'extra_space',
		'id'    	=> 	'extra_space_no',
		'value'  	=> 	'0',
		'checked'	=> 	isset($result->addtional_space) ? '': 'checked' 
	);
	$addtional_space = array(
        'name'  => 'addtional_space',
        'value' => isset($result->addtional_space) ? $result->addtional_space : set_value('addtional_space')
    );
    if(isset($result->custom) AND $result->custom !='1')
        $space_field = array_merge($space_field,array('type'=>'hidden'));
    $price_field = array(
        'name'  => 'price',
        'value' => isset($result->price)? $result->price : set_value('price'),
        'class'	=> 'txt-right'
    );
    $storage_prifix = array(
		'name'          =>  'storage_prifix',
		'value'         =>  (!empty($result->storage))? $parking[0] : set_value('storage_prifix'),
		'class'         =>  'w90 txt-right',
        'placeholder'   =>  'PC,PCI,HCP'
	);
    $storage_range = array(
		'name'          =>  'storage_range',
		'value'         =>  (!empty($result->storage))? $parking[1] : set_value('storage_range'),
		'class'     	=>  'w90 txt-right',
        'placeholder'   =>  '0-10,50-55,10'
	);
	$submit = array(
		'name' => 'submit',
		'value' => 'Save',
		'class' => 'btn btn-primary'
	);
	$cancel = array(
		'name' =>  'cancel',
		'value'=> 'cancel',
		'class'=> 'btn'
	);		
?>
<div class="content">
    <div class="content-inner">
		<?php
			$attributes = array('class' => 'storagefrm', 'id' => 'storagefrm');
			echo form_open('storage/operation/add',$attributes);
			echo form_hidden('storage_id',isset($result->id) ? md5($result->id) : set_value('storage_id'));
			echo form_hidden('building_id',isset($result->building_id) ? $result->building_id : set_value('building_id'));
			echo form_hidden('custom',isset($result->custom) ? $result->custom : set_value('custom'));
			echo form_hidden('space',  isset($result->space) ? $result->space : set_value('space    '));
		?>
		<div class="modal-header">
			<button type="button" class="close close-icon" data-dismiss="modal"><i class="icon-remove"></i></button>
            <h3>Storage Detail</h3>
		</div>
        <div class="modal-body">
            <div class="span4 mrg0">
                <label>Building : <b class="build-name"><?php echo isset($result->building) ? $result->building : '' ?> </b></label>
                <label>Storage Space: <b><?php echo (isset($result->space) AND $result->custom != '1') ? 'S'.$result->space : '' ?><?php echo (isset($result->space) AND $result->type != '1') ? ucwords($result->type_name).$result->space : '' ?></b></label>
                <?php //echo form_input($space_field) ?>
                <div class="input-prepend <?php echo (isset($result->id)) ? 'hide' : ''?>">
                    <span class="add-on">Prefix:</span><?php echo form_input($storage_prifix); ?><span class="add-on">Range:</span><?php echo form_input($storage_range); ?>
                </div>
                <div class="error">
                    <?php echo form_error('space'); ?>
                </div>
                <label>Storage Type:</label>
                <?php echo form_dropdown('type', $storage_option, isset($result->type) ? $result->type : ''); ?>
                <div class="error">
                    <?php echo form_error('type'); ?>
                </div>
                <label>Price:</label>
                <?php echo form_input($price_field); ?>
                <div class="error">
                    <?php echo form_error('price'); ?>
                </div>
                <label>Add Additional Space:<?php echo  form_radio($extra_space_yes). ' Yes';?><?php echo '  '.form_radio($extra_space_no).' No'; ?>				
                <div class="error">
                    <?php echo form_error('holdback'); ?>
                </div>
                <div class="additional-space <?php echo isset($result->addtional_space) ? '' : 'hide'; ?>">
                    <label>Additional Space:</label>
                    <?php echo form_input($addtional_space); ?>
                    <div class="error">
                        <?php echo form_error('addtional_space'); ?>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
		<div class="modal-footer">
			<div class="pull-left">
                <?php echo form_submit($submit); ?><span class="mrgl10"><a href="#" class="btn" data-dismiss="modal">Cancel</a></span>
            </div>
		</div>
		<?php echo form_close(); ?>
	</div>
</div>