        <script>
            $(document).ready(function() {
                $.app.data_table.project();
            });
        </script>        
        <div class="content">
        	<div class="content-inner">    
                <div class="row alert alert-success <?php echo (!isset($status_messages['flash_success'])) ? 'hide' : '' ?>">
                	<button type="button" class="close" data-dismiss="alert">×</button>
					<span><?php echo (isset($status_messages['flash_success'])) ? $status_messages['flash_success'] : '' ?></span>
                </div>
                <h3>Project</h3>
                <div class="create-link"><?php echo anchor('project/add-project','Add Project'); ?></div>
                <table cellpadding="0"  cellspacing="0" border="0" class="table table-striped " id="project-listing">   
                    <thead>
                        <tr>
							<th>id</th>
							<th>&nbsp;</th>
							<th>Name</th>
							<th>Phase</th>
                            <th>Date Created</th>
                            <th>action</th>
                        </tr>
                    </thead>
                    <tbody><tr><td colspan="5" class="tc">Loading Data...</td></tr></tbody>
                </table>
				<div id="overlay" class="hide overlay"></div>