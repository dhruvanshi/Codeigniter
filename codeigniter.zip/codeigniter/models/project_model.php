<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Project_model extends MY_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
        $this->tableName = 'project';
    }
    
    function get_company()
    {
        $filters = array();
        $filters['select'] = array('id','name');
        return $this->get_rows('company',$filters);
    }
	function get_type()
    {
        $filters = array();
        $filters['select'] = array('id','name');
        return $this->get_rows('project_type',$filters);
    }
}

/* End of file company_model.php */
/* Location: ./application/model/project_model.php */
?>